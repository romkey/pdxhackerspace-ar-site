import esphome.codegen as cg

CODEOWNERS = ["@yourusername"]

stcc4_ns = cg.esphome_ns.namespace("stcc4")

